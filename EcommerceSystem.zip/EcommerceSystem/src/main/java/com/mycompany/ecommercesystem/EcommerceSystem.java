/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ecommercesystem;

/**
 *
 * @author Malak Elsayed
 */
import javax.swing.JOptionPane ;
import java.util.Scanner ;
public class EcommerceSystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in) ;
        
         JOptionPane.showMessageDialog(null,"Welcome to E-commerce System");
       
        
        int id = Integer.parseInt(JOptionPane.showInputDialog("Please, Enter your id")) ;
       String name = JOptionPane.showInputDialog("Enter your name") ;
        String address = JOptionPane.showInputDialog("Enter your address") ;
        int numOfItems = Integer.parseInt(JOptionPane.showInputDialog("How many products you want to add to your cart")); 
        
        Customer c = new Customer(id , name , address) ;
       
        
        
         if(numOfItems<0){
             numOfItems = Math.abs(numOfItems) ;
         }
         else if(numOfItems>0){
             numOfItems = numOfItems ;
         }
         
         
       Cart cartt = new Cart(id , numOfItems) ;
       
       
       
         ElectronicProduct ep = new ElectronicProduct(1 , "smart phone" , (float) -599.9, "Samsung" , 1);
         ClothingProduct cp = new ClothingProduct(2 , "T-shirt" ,(float)19.99 , "Medium" , "Cotton");
         BookProduct bp = new BookProduct(3 , "OOP" , (float)-39.99 , "O'Reilly" , "X Publications");
         
         
         
        for(int i = 0 ; i<numOfItems ; i++){
            int Itemnum = Math.abs(Integer.parseInt(JOptionPane.showInputDialog("Which product you would like to add? 1-Smart phone  2-T-shirt  3 -OOP"))) ;
            
            
              switch(Itemnum){
                case 1 : 
                    
                      cartt.addProduct(ep);   
                      
                     break ;
                case 2 :
                    
                     cartt.addProduct(cp);
                     
                    break ;
                case 3 :
                    
                     cartt.addProduct(bp);
                     
                    break ;
                default :
                    JOptionPane.showMessageDialog(null,"the option you selected is not found!");
            }
        }
      
         cartt.placeOrder();
        
    
    }
}
