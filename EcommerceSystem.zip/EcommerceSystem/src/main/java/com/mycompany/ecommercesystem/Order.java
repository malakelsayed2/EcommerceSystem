/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommercesystem;

import javax.swing.JOptionPane;

/**
 *
 * @author Malak Elsayed
 */
public class Order {
   private int customerId ;
    private int orderId ;
   private Product[] products  ; 
   private float totalPrice ;
   
    
    Order(){
        
    }
    
    Order(int customerId  , int orderId ,Product []products , float totalPrice){
        this.customerId = Math.abs(customerId) ;
        this.orderId = Math.abs(orderId) ;
        this.totalPrice = Math.abs(totalPrice) ;
         this.products= products ;
    }
    
    public void printOrderInfo(){
      String messege = "" ;
           for( Product p : products){
            messege += (p.getName() + " - " +p.getPrice() + "$" + "\n") ;
   }
         

 JOptionPane.showMessageDialog(null, "Here is your order's summary\n" +"Order ID : " + this.orderId +"\n Customer ID :" + this.customerId +"\nProducts :" +"\n" + messege + "\n Total price : "+ this.totalPrice) ;
        JOptionPane.showMessageDialog(null,"Thank you for ordering from  E-commerce System!");
        
    }
   }
    
    
