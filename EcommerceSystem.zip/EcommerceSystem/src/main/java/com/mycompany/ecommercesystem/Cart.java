/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommercesystem;

/**
 *
 * @author Malak Elsayed
 */

import javax.swing.JOptionPane;
public class Cart {
  private  int customerId ;
   private  int nProducts ;
   private int element=0;
   private Product [] products ;   // size nProducts

    Cart(){
        
    }
    
  
    
    Cart( int customerId ,int nProducts ){
        this.customerId = Math.abs(customerId);
        this.nProducts = Math.abs(nProducts) ;
        this.products= new Product[this.nProducts] ;   // size nProducts

        
     
    }       
    
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = Math.abs(customerId);
    }

    public int getnProducts() {
        return nProducts;
    }

    public void setnProducts(int nProducts) {
        this.nProducts = Math.abs(nProducts);
    }

    public Product[] getProducts() {
        return products;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }
    
    
    public Product[] addProduct(Product pro){
       
        products[this.element]=pro;
        this.element++;
      return products ;
    }
    
    public void removeProduct(int productIndex) {
            if (productIndex < 0 || productIndex >= nProducts) {
           System.out.println("Invalid product index. Cannot remove product.");
             return;
             }
             for (int i = productIndex; i < nProducts - 1; i++) {
                 products[i] = products[i + 1];
          }
               nProducts -- ;
          } 
     
      public float calculatePrice(){
         float sum = 0 ;
         
         for ( Product r: products )
         {
            
             sum+=r.getPrice();
         }
        
        return sum ;
    }
      
       public void placeOrder(){
   
           int choice = Integer.parseInt(JOptionPane.showInputDialog("your total is $"+ calculatePrice() +" .Would you like to place order? 1-yes 2-no"));
           switch(choice){
               case 1 :  
            Order o = new Order(this.customerId ,-1, products  ,calculatePrice());
            o.printOrderInfo();
            break ;
               default:
               break ;
           }
    }
}
